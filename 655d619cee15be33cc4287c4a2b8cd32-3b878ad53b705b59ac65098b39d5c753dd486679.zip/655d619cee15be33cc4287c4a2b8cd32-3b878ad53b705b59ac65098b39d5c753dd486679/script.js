function showCharacter(id) {
  document.getElementById(id).style.display = 'block';
  document.querySelector('.container').style.display = 'none';
  document.querySelector('header').style.display = 'none';
}

function closeCharacter(id) {
  document.getElementById(id).style.display = 'none';
  document.querySelector('.container').style.display = 'flex';
  document.querySelector('header').style.display = 'block';
}
